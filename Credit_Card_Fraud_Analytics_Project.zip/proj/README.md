# Credit Card Fraud Analytics - Capstone 1 (AnalytIQ Edge)
- 01_BRD/ - Business Requirements Document (Task 1)
- 02_Excel/ - Credit_Card_Fraud_Analysis.xlsx (Tasks 2-3: stats, histogram, pivots, charts, correlation, AI risk summary)
- 03_SQL/ - schema/load, exploration, aggregation scripts (MySQL) + validated results (Tasks 4-6)
- 04_PowerBI/ - build guide, DAX, browser dashboard preview (Task 7)
- data/ - source CSVs
Notes: Power BI .pbix must be built in Power BI Desktop (guide included). AI.TABLE / ChatGPT for Excel need those add-ins; prompts and an equivalent summary are included.
