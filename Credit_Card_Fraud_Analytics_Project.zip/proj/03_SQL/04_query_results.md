# SQL Query Results (validated on the provided data)

## Total transactions

|   total_transactions |
|---------------------:|
|                42308 |

## Top 10 merchants

| merchant                                    |   txn_count |
|:--------------------------------------------|------------:|
| fraud_Kilback LLC                           |         158 |
| fraud_Cormier LLC                           |         124 |
| fraud_Mraz-Herzog                           |         114 |
| fraud_Reilly, Heaney and Cole               |         113 |
| fraud_Kuhn LLC                              |         113 |
| fraud_Schumm PLC                            |         110 |
| fraud_Hackett-Lueilwitz                     |         107 |
| fraud_Christiansen, Goyette and Schamberger |         107 |
| fraud_Stroman, Hudson and Erdman            |         101 |
| fraud_Dickinson Ltd                         |         101 |

## Avg amount by category

| category       |   avg_amt |
|:---------------|----------:|
| travel         |    121.69 |
| grocery_pos    |    115.74 |
| shopping_net   |     85.2  |
| shopping_pos   |     79.4  |
| misc_net       |     76.4  |
| misc_pos       |     64.42 |
| gas_transport  |     63.44 |
| entertainment  |     62.7  |
| home           |     58.35 |
| kids_pets      |     58.02 |
| health_fitness |     54.38 |
| grocery_net    |     54.37 |
| food_dining    |     50.9  |
| personal_care  |     49.02 |

## Fraud count and %

|   fraud_txns |   fraud_pct |
|-------------:|------------:|
|          180 |       0.425 |

## Join sample (first 5 of 42,308 rows)

| trans_num                        |   amt |     lat |     long |
|:---------------------------------|------:|--------:|---------:|
| b0e6e23559789dcb5859387f170a440f | 59.62 | 31.6591 | -96.8094 |
| 2132a7ecdd6f86275b545ae04983026f |  9.52 | 29.7972 | -95.3288 |
| 75bad13e134e7273a498b327735ffb31 | 75.86 | 37.2876 | -77.295  |
| 4e141388a066af02244f3b01721c97db |  4.03 | 24.6557 | -81.3824 |
| 61b06343276629ede9c52798ca078506 | 42.4  | 44.232  | -74.4905 |

## Join row count

|   joined_rows |
|--------------:|
|         42308 |

## Highest-population city

| city    | state   |   population |
|:--------|:--------|-------------:|
| Houston | TX      |      2906700 |

## Earliest/latest date

| earliest            | latest              |
|:--------------------|:--------------------|
| 2019-12-01 00:02:00 | 2019-12-31 23:59:00 |

## Total amount

|   total_amount |
|---------------:|
|    2966148.83 |

## Transactions per category

| category       |   txn_count |
|:---------------|------------:|
| gas_transport  |        4356 |
| home           |        3982 |
| grocery_pos    |        3940 |
| shopping_pos   |        3812 |
| kids_pets      |        3633 |
| shopping_net   |        3234 |
| entertainment  |        3060 |
| personal_care  |        3026 |
| food_dining    |        2898 |
| health_fitness |        2770 |
| misc_pos       |        2655 |
| misc_net       |        2085 |
| grocery_net    |        1544 |
| travel         |        1313 |

## Avg amount by gender

| gender   |   avg_amt |
|:---------|----------:|
| F        |     69.89 |
| M        |     70.37 |

## Avg amount by day of week

| day_of_week   |   avg_amt |
|:--------------|----------:|
| Monday        |     74.24 |
| Tuesday       |     72.88 |
| Saturday      |     69.94 |
| Friday        |     69.29 |
| Thursday      |     68.67 |
| Sunday        |     67.37 |
| Wednesday     |     67.31 |

## Weekly trend

|   iso_year_week |   txns |   total_amt |   frauds |
|----------------:|-------:|------------:|---------:|
|          201948 |   1946 |      135942 |        4 |
|          201949 |   9538 |      696960 |       43 |
|          201950 |   9506 |      659467 |       33 |
|          201951 |   9207 |      638838 |       34 |
|          201952 |   9402 |      637265 |       49 |
|          202001 |   2709 |      197677 |       17 |
