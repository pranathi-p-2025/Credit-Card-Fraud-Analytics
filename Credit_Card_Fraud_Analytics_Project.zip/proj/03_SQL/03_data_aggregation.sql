-- Task 6: Data Aggregation
USE finance;

-- 1. Total amount spent
SELECT ROUND(SUM(amt),2) AS total_amount FROM cc_data;

-- 2. Transactions per category
SELECT category, COUNT(*) AS txn_count FROM cc_data GROUP BY category ORDER BY txn_count DESC;

-- 3. Average transaction amount per gender
SELECT gender, ROUND(AVG(amt),2) AS avg_amt FROM cc_data GROUP BY gender;

-- 4. Day of week with highest average transaction amount
SELECT DAYNAME(trans_ts) AS day_of_week, ROUND(AVG(amt),2) AS avg_amt
FROM cc_data GROUP BY DAYNAME(trans_ts) ORDER BY avg_amt DESC LIMIT 1;

-- Bonus: weekly trend (problem statement mentions weekly trends)
SELECT YEARWEEK(trans_ts,1) AS year_week, COUNT(*) AS txns,
       ROUND(SUM(amt),2) AS total_amt, SUM(is_fraud) AS frauds
FROM cc_data GROUP BY YEARWEEK(trans_ts,1) ORDER BY year_week;
