-- Task 5: Data Exploration
USE finance;

-- 1. Total number of transactions
SELECT COUNT(*) AS total_transactions FROM cc_data;

-- 2. Top 10 most frequent merchants
SELECT merchant, COUNT(*) AS txn_count
FROM cc_data GROUP BY merchant ORDER BY txn_count DESC LIMIT 10;

-- 3. Average transaction amount per category
SELECT category, ROUND(AVG(amt),2) AS avg_amt
FROM cc_data GROUP BY category ORDER BY avg_amt DESC;

-- 4. Fraud count and % of total
SELECT SUM(is_fraud) AS fraud_txns,
       ROUND(100*SUM(is_fraud)/COUNT(*),3) AS fraud_pct
FROM cc_data;

-- 5. Join to get latitude/longitude of each transaction
--    (location file holds the card number in scientific notation, so we join on the
--     6-significant-digit key AND matching coordinates -> exactly one row per transaction)
SELECT c.trans_num, c.cc_num, c.amt, l.lat, l.`long`
FROM cc_data c
JOIN location_data l
  ON c.cc_key = l.cc_key AND c.lat = l.lat AND c.`long` = l.`long`;

-- 6. City with the highest population (location_data has no city_pop; city_pop lives in cc_data)
SELECT c.city, c.state, MAX(c.city_pop) AS population
FROM cc_data c
JOIN location_data l ON c.cc_key = l.cc_key AND c.lat = l.lat AND c.`long` = l.`long`
GROUP BY c.city, c.state ORDER BY population DESC LIMIT 1;

-- 7. Earliest and latest transaction dates
SELECT MIN(trans_ts) AS earliest, MAX(trans_ts) AS latest FROM cc_data;
