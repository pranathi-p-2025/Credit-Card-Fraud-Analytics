-- Task 4: Data Loading (MySQL 8)
CREATE SCHEMA IF NOT EXISTS finance;
USE finance;

DROP TABLE IF EXISTS cc_data;
CREATE TABLE cc_data (
    idx                   INT,
    trans_date_trans_time VARCHAR(20),
    cc_num                DECIMAL(20,0),
    merchant              VARCHAR(150),
    category              VARCHAR(30),
    amt                   DECIMAL(12,2),
    first                 VARCHAR(50),
    last                  VARCHAR(50),
    gender                CHAR(1),
    street                VARCHAR(120),
    city                  VARCHAR(80),
    state                 CHAR(2),
    zip                   INT,
    lat                   DECIMAL(9,4),
    `long`                DECIMAL(9,4),
    city_pop              INT,
    job                   VARCHAR(100),
    dob                   VARCHAR(12),
    trans_num             VARCHAR(40),
    is_fraud              TINYINT,
    trans_ts              DATETIME,
    PRIMARY KEY (idx)
);

DROP TABLE IF EXISTS location_data;
CREATE TABLE location_data (
    cc_num_raw VARCHAR(30),      -- stored in scientific notation in the CSV (e.g. 3.58601E+15)
    lat        DECIMAL(9,4),
    `long`     DECIMAL(9,4),
    cc_key     BIGINT            -- cc_num rounded to 6 significant digits (join key)
);

-- Adjust the path (use secure_file_priv folder or MySQL Workbench Table Data Import Wizard)
LOAD DATA LOCAL INFILE 'cc_data.csv' INTO TABLE cc_data
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\r\n' IGNORE 1 LINES
(idx, @ts, cc_num, merchant, category, amt, first, last, gender, street, city, state, zip, lat, `long`, city_pop, job, dob, trans_num, is_fraud)
SET trans_ts = STR_TO_DATE(@ts, '%d-%m-%Y %H:%i'), trans_date_trans_time = @ts;

LOAD DATA LOCAL INFILE 'location_data.csv' INTO TABLE location_data
FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n' IGNORE 1 LINES
(cc_num_raw, lat, `long`);

UPDATE location_data
SET cc_key = ROUND(CAST(cc_num_raw AS DOUBLE) / POW(10, FLOOR(LOG10(CAST(cc_num_raw AS DOUBLE))) - 5));

ALTER TABLE cc_data ADD COLUMN cc_key BIGINT;
UPDATE cc_data SET cc_key = ROUND(cc_num / POW(10, FLOOR(LOG10(cc_num)) - 5));
CREATE INDEX ix_cc_key ON cc_data(cc_key);
CREATE INDEX ix_loc_key ON location_data(cc_key);
