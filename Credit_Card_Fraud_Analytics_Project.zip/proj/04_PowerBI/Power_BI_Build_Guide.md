# Power BI Build Guide (Task 7)
A .pbix file cannot be generated outside Power BI Desktop, so this guide + `Fraud_Dashboard_Preview.html` (same visuals, open in a browser) + `DAX_Measures.dax` are provided. Build time: ~10 minutes.

1. Get data > Text/CSV > `../data/cc_data.csv` > Load (also load `location_data.csv` if needed).
2. Data view: select `lat` > Data category = Latitude; `long` > Data category = Longitude. Set `is_fraud` to Text/Whole number as needed.
3. Visualizations > ... > Get more visuals > **Box and Whisker Chart (MAQ Software)** > Add. Values = `amt`, Axis = `category`, Legend = `gender`; Format > Data labels On.
4. Map visual #1 (Transaction Map): Latitude = `lat`, Longitude = `long`.
5. Map visual #2 (Fraud Map): Latitude = `lat`, Longitude = `long`, Legend = `is_fraud`; add visual-level filter `is_fraud = 1`.
6. Modeling > Quick measure > Aggregate per category > **Average per category**; Base value = `amt`, Category = `category` > Add (DAX in `DAX_Measures.dax`).
7. Clustered column chart: Axis = `category`, Values = the new measure.
8. Arrange Box & Whisker (top, wide), the two maps (middle), column chart (bottom); save as `Credit_Card_Fraud_Dashboard.pbix`.
